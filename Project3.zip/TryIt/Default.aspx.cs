﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TryIt
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            WebDownload.Service1Client client = new WebDownload.Service1Client(); 
            string url = TextBox1.Text;
            string content = client.WebDownload(url);
            ListBox1.Items.Clear();
            ListBox1.Items.Add(content);
        }

        // filter word 
        protected void Button2_Click(object sender, EventArgs e)
        {
            wordfilter.Service1Client client = new wordfilter.Service1Client();
            try
            {
                string result = client.WordFilter(TextBox2.Text);
                TextBox3.Text = result;
            }
            catch (Exception ex)
            {
                TextBox3.Text = ex.Message.ToString();

            }
        }
    }
}
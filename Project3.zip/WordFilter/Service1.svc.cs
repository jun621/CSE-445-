﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Text.RegularExpressions;

namespace WordFilter
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string WordFilter(string input)
        {
            string atStr = @input;
            string oldStr = @"(</?)[^>]+?(/?>)|[^a-zA-Z]";
            string oldStr1 = @"\bare\b|\bam\b|\ba\b|\bthe\b|\ban\b|\bin\b|\bon\b|\bis\b";
            string dataStr = Regex.Replace(atStr, oldStr, " ").ToLower();
            string dataStr1 = Regex.Replace(dataStr, oldStr1, " ");

            ArrayList List = new ArrayList();

            foreach (string s in dataStr1.Split())
            {

                if (s.Trim().Length != 0)
                {
                    List.Add(s);
                }


            }

            string completeStr = string.Join(" ", (string[])List.ToArray(typeof(string)));

            return completeStr;

        }
    }
}

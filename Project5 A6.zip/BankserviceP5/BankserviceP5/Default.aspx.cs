﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BankserviceP5
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // Login button 
        protected void Button1_Click(object sender, EventArgs e)
        {
           ServiceReference2.Service1Client client = new ServiceReference2.Service1Client();
            string username = TextBox1.Text;
            string password = TextBox2.Text;

            string result = client.AuthenticateUser(username, password);

            TextBox3.Text = result;

        }
        // withdraw button 
        protected void Button2_Click(object sender, EventArgs e)
        {
            ServiceReference2.Service1Client client = new ServiceReference2.Service1Client();
            decimal withdrawalAmount = decimal.Parse(TextBox4.Text);

            string withdrawalMessage = client.Withdraw(withdrawalAmount);

            TextBox5.Text = withdrawalMessage;


        }
        // Deposit button 
        protected void Button3_Click(object sender, EventArgs e)
        {
            ServiceReference2.Service1Client client = new ServiceReference2.Service1Client();
            decimal depositAmount = decimal.Parse(TextBox6.Text);
            string userIdentifier = TextBox7.Text;


            string depositMessage = client.Deposit(depositAmount, userIdentifier);

            TextBox8.Text = depositMessage;


        }
        // Hashing function 
        protected string hashPassword(string password)
        {
            ServiceReference2.Service1Client client = new ServiceReference2.Service1Client();
            string newPass = "";
            string pass = "JZ%986fp1*";
            byte[] hashCode;
            UnicodeEncoding Uce = new UnicodeEncoding();
            byte[] BytesShort = Uce.GetBytes(password);
            SHA1Managed SHhash = new SHA1Managed();
            hashCode = SHhash.ComputeHash(BytesShort);
            foreach (byte b in hashCode)
            {
                newPass += b.ToString();
            }

            string Password = client.Hashfunction(newPass, pass);
            return Password;
        }


    }
}
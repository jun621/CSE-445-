﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace P5BankService
{
    public class Service1 : IService1
    {

        // user can deposit money to the designated account
        public string Deposit(decimal amount, string userIdentifier)
        {
            // Check if the amount is empty or not a valid number
           if( amount <= 0 || string.IsNullOrWhiteSpace(userIdentifier))
            {
                return "Invalid amount or user identifier. Please enter valid values.";
            }

            // Return a message indicating the result of the deposit.
            return $"You have deposited ${amount} to {userIdentifier}.";
        }

        // user can withdraw money from the designated account
        public string Withdraw(decimal amount)
        {
            // Check if the amount is empty or not a valid number
            if (amount <= 0 || !decimal.TryParse(amount.ToString(), out _))
            {
                return "Invalid amount. Please enter a valid positive number.";
            }

            // Return a message indicating the result of the withdrawal.
            return $"You have withdrawn ${amount}.";
        }

        // If the username and password either matches one of the following user can login 
        public string AuthenticateUser(string username, string password)
        {
            if (username == "Junichi" && password == "jkoizum1" || username == "Marc" && password == "marc1" ||
                username == "Zack" || password == "zack1")
            {
                return "Login successfull";

            }
            else
            {

                return "login failed";
            }



        }

        // Hashing function for encrypting user input 
        public string Hashfunction(string value, string pass)
        {
            using (var sha = new SHA512CryptoServiceProvider())
            {
                var hashedString = sha.ComputeHash(Encoding.Default.GetBytes(value + pass));
                return Convert.ToBase64String(hashedString);
            }
        }


    }
}

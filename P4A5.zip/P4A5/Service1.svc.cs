﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using System.Xml.Xsl;
using System.Net;
using System.Xml.XPath;
 


namespace P4A5
{

    
    public class Service1 : IService1
    {

        // verification 
        public string verification(string xmlurl, string xmlsurl)
        {
            
            string Output = "NoErrors";

           
            string xml;

            // Create a set to hold XML schemas
            var set = new XmlSchemaSet();

            using (var webclient = new WebClient())
            {
                try
                {
                    // Attempt to download XML content from the provided URL
                    xml = webclient.DownloadString(xmlurl);
                }
                catch (Exception ex)
                {
                    // If an exception occurs, set output message to indicate invalid XML URL
                    Output = "The XML URL is invalid";
                    return Output;
                }
            }

            var xsd = new XmlDocument();

            try
            {
                // Load the XML content into an XmlDocument
                xsd.LoadXml(xml);
            }
            catch (XmlException ex)
            {
                // If an exception occurs during XML loading, set output message to the exception message
                Output = ex.ToString();
                return Output;
            }

        
            var xmldoc = XmlDocToXDoc(xsd);

            // Add the XML schema to the schema set
            set.Add(null, xmlsurl);

            // Validate the XML document against the schema
            xmldoc.Validate(set, (o, e) =>
            {
                
                Output = e.Message;
            });

            
            return Output;
        }





        private static XDocument XmlDocToXDoc(XmlDocument xmldoc)
        {
            return XDocument.Load(new XmlNodeReader(xmldoc));

        }

        // XPathSearch 
        public string XPathSearch(string xmlurl, string xpath)
        {
            // Find the last occurrence of '/' in the xpath
            int i = xpath.LastIndexOf('/');
            string path = "";
            string choose;

            // Determine the element to choose based on the position of '/'
            if (i >= 0)
            {
                choose = xpath.Substring(i + 1);
            }
            else
            {
                choose = "unfound"; 
            }

            try
            {
                // Load the XML document for XPath querying
                XPathDocument doc = new XPathDocument(xmlurl);
                XPathNavigator navigator = doc.CreateNavigator();

                // Select the nodes to iterate over (based on xpath)
                XPathNodeIterator Iterator = navigator.Select(i >= 0 ? xpath.Substring(0, i) : xpath);

                while (Iterator.MoveNext())
                {
                    // Select the sub-node specified by 'choose'
                    XPathNodeIterator iterator = Iterator.Current.Select(choose);
                    iterator.MoveNext();

                    // Get the value of the selected node
                    string value = iterator.Current.Value;

                    // Append the value to the path string
                    path = path + value + ", ";
                }

                // Remove the trailing ", " and return the resulting path
                return path.Substring(0, path.Length - 2);
            }
            catch (Exception e)
            {
                
                return e.Message;
            }
        }







    }

}


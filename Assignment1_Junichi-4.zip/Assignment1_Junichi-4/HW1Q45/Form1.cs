﻿// Assignment 1 Q4&5 
// Junichi Koizumi 

using System;
using System.Net;
using System.Windows.Forms;

namespace HW1Q45
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /* getting temprature 
       private void button6_Click(object sender, EventArgs e)
        {
            string url = "https://www.meteomatics.com/en/weather-api";
            try
            {
                using (WebClient client = new WebClient())
                {

                    string tempData = client.DownloadString(url);
                    string Content = $"<html><body><h2>Current Temprature: {tempData}</h2></body></html>";

                    webBrowser2.Text = Content;

                }
            } catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        } */

        // Encryption button 
        private void button6_Click_1(object sender, EventArgs e)
        {

            string texttoEncrypt = textBox5.Text; // allows user to enter a text to encrypt
            ServiceReference2.ServiceClient service = new ServiceReference2.ServiceClient();    
            string EncryptedText = service.Encrypt(texttoEncrypt); // encrypts the text the user entered 

            textBox6.Text = EncryptedText;  // displays the encrypted text 


        }


        // Decryption button 
        private void button7_Click(object sender, EventArgs e)
        {
            string texttoDecrypt = textBox6.Text; // signifies the text to decrypt
            ServiceReference2.ServiceClient service = new ServiceReference2.ServiceClient();
            string DecryptedText = service.Decrypt(texttoDecrypt); // decrypts the ecnrypted text 

            textBox7.Text = DecryptedText; // displays the decrypted text 
        }

        // Go 
        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(textBox1.Text); // web navigates to the url entered 
        }

        // +
        private void button2_Click(object sender, EventArgs e)
        {
            double text1 = Convert.ToDouble(textBox2.Text);
            double text2 = Convert.ToDouble(textBox3.Text); 

            double sum = text1 + text2; // summation of the two numbers
            textBox4.Text = sum.ToString();
        }

        // - 
        private void button3_Click(object sender, EventArgs e)
        {
            double text1 = Convert.ToDouble(textBox2.Text);
            double text2 = Convert.ToDouble(textBox3.Text);

            double sub = text1 - text2; // subtraction of the two numbers 
            textBox4.Text = sub.ToString();
        }

        // *
        private void button4_Click(object sender, EventArgs e)
        {
            double text1 = Convert.ToDouble(textBox2.Text);
            double text2 = Convert.ToDouble(textBox3.Text);

            double mult = text1 * text2; // multiplication of the two numbers 
            textBox4.Text = mult.ToString();
        }
        // /
        private void button5_Click(object sender, EventArgs e)
        {
            double text1 = Convert.ToDouble(textBox2.Text);
            double text2 = Convert.ToDouble(textBox3.Text);

            double div = text1 / text2; // divison of the two numbers 
            textBox4.Text = div.ToString();
        }
    }
}

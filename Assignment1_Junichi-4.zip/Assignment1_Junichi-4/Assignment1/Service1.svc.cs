﻿// Junichi Koizumi
// 8/25/2023 
// Project 1 Assignment 1 Q1&2

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Assignment1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1

    {


        // celsius to farenheit conversion 
      public int c2f(int c)  
        {
            int f = c * 9 / 5 + 32;  // converts the celsius to farenheit 

            return f; // returns the converted value 
        }

       
        // farenheit to celsius conversion 
       public int f2c(int f)
        {
            
            int c = (f - 32) * 5 / 9; // converts farenheit to celsius 

            return c; // returns the converted value 
        }

        // sort the array function 
      public  string sort(string s)
        {
            string[]  nums = s.Split(','); // split the commas between the numbers in the array 
            int[] parsedNum = Array.ConvertAll(nums, int.Parse); // parse all the numbers 
            Array.Sort(parsedNum); // sort the unsorted array 
            string sortedNums = string.Join(",", parsedNum); // add the comma between each element of the sorted array  
            return sortedNums;   // return the sorted array 

        }

    }
}

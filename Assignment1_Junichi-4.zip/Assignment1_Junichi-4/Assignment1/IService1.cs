﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
// Assignment 1 Q1&2 
// Junichi Koizumi 
using System.Text;

namespace Assignment1
{
   
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        int c2f(int c); //  convert Celsius temperature to Fahrenheit temperature
        [OperationContract]
        int f2c(int f); //  convert Fahrenheit temperature to Celsius temperature 
        [OperationContract]
        string sort(string s); // function which sorts a string of numbers seperated by a comma 

    }


    
}

﻿// Assignment 1 Q3 
// Junichi Koizumi 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW1Q3
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // c to f function 

        protected void Button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
            int celsiusTemp = int.Parse(TextBox1.Text);
            int Farenheit = client.c2f(celsiusTemp);
            TextBox2.Text = Farenheit.ToString(); 


        }
        // f to c function 
        protected void Button2_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
            int farenheitTemp = int.Parse(TextBox3.Text);
            int Celsius = client.f2c(farenheitTemp);
            TextBox4.Text = Celsius.ToString();
        }


        // sort number function 
        protected void Button3_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
            string unsortednums = TextBox5.Text;
            string sorted = client.sort(unsortednums);

            TextBox6.Text = sorted;

        }
    }
}
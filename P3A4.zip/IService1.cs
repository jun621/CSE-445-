﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace P3Assignment4
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/AuthenticateUser", ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string AuthenticateUser(string username, string password);

        [OperationContract]
        string Deposit(decimal amount, string userIdentifier);

        [OperationContract]
        string Withdraw(decimal amount);

        [OperationContract]
        string BankFilter(string input);



        [OperationContract]
        string LinkBankAccount(string bankName);


        // TODO: Add your service operations here
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.


}

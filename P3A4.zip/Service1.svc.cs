﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Text.RegularExpressions;

namespace P3Assignment4
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {

        // bank  filtering function that excludes any unmeanigful words 
        public string BankFilter(string input)
        {
            string atStr = @input;
            string oldStr = @"(</?)[^>]+?(/?>)|[^a-zA-Z]";
            string oldStr1 = @"\bare\b|\bam\b|\ba\b|\bthe\b|\ban\b|\bin\b|\bon\b|\bis\b";
            string dataStr = Regex.Replace(atStr, oldStr, " ").ToLower();
            string dataStr1 = Regex.Replace(dataStr, oldStr1, " ");

            ArrayList List = new ArrayList();

            foreach (string s in dataStr1.Split())
            {

                if (s.Trim().Length != 0)
                {
                    List.Add(s);
                }
            }

            string completeStr = string.Join(" ", (string[])List.ToArray(typeof(string)));

            return completeStr;

        }




        // user can deposit money to the designated account
        public string Deposit(decimal amount, string userIdentifier)
        {

            // Return a message indicating the result of the deposit.
            return $"You have deposited ${amount} to {userIdentifier}.";
        }

        // user can withdraw money from the designated account
        public string Withdraw(decimal amount)
        {

            // Return a message indicating the result of the withdrawal.
            return $"You have withdrawn ${amount}.";
        }

        // If the username and password either matches one of the following user can login 
        public string AuthenticateUser(string username, string password)
        {
            if (username == "Junichi" && password == "jkoizum1" || username == "Marc" && password == "marc1" ||
                username == "Zack" || password == "zack1")
            {
                return "Login successfull";

            }
            else
            {

                return "login failed";
            }



        }

        // link bank account from the 5 major banks in the dropdown list 
        public string LinkBankAccount(string bankName)
        {

            return $"Bank account  linked successfully for bank {bankName}.";
        }

    }
}
